"""
To run this project:
    uvicorn main:app --reload

Then open Swagger UI at:
    http://127.0.0.1:8000/docs
"""

from fastapi import FastAPI

from routes import categories, games, tables, sessions

app = FastAPI(
    title="Board Game Café Management System",
    description=(
        "A MongoDB + FastAPI project to manage a board game café: "
        "categories, games, tables, and play sessions."
    ),
    version="1.0.0",
)

# Register each router.
# Every route defined inside these files will now be part of the app.
app.include_router(categories.router)
app.include_router(games.router)
app.include_router(tables.router)
app.include_router(sessions.router)


@app.get("/", tags=["Root"])
def root():
    """Simple health-check / welcome endpoint."""
    return {
        "message": "Welcome to the Board Game Café Management System API",
        "docs": "/docs"
    }


from routes.reports import router as reports_router

app.include_router(
    reports_router,
    prefix="/reports",
    tags=["Reports"]
)