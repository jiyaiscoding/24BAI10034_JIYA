from datetime import datetime
from fastapi import HTTPException

from database import sessions_collection, tables_collection, games_collection
from models.session import SessionStartRequest


def start_session(data: SessionStartRequest):

    # 1. Check that the session_id is not already used
    if sessions_collection.find_one({"session_id": data.session_id}):
        raise HTTPException(status_code=400, detail="session_id already exists")

    # 2. Check that the table exists
    table = tables_collection.find_one({"table_id": data.table_id})
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")

    # 3. Check that the table is available
    if table["status"] != "Available":
        raise HTTPException(status_code=400, detail="Table is not available")

    # 4. Check that every requested game exists and is available
    for game_id in data.game_ids:
        game = games_collection.find_one({"game_id": game_id})
        if not game:
            raise HTTPException(status_code=404, detail=f"Game '{game_id}' not found")
        if game["status"] != "Available":
            raise HTTPException(
                status_code=400,
                detail=f"Game '{game_id}' is not available"
            )

    # 5. All checks passed - create the session document
    session_doc = {
        "session_id": data.session_id,
        "group_name": data.group_name,
        "table_id": data.table_id,
        "game_ids": data.game_ids,
        "player_count": data.player_count,
        "status": "Active",
        "start_time": datetime.utcnow(),
        "end_time": None,
    }
    sessions_collection.insert_one(session_doc)

    # 6. Mark the table as Occupied
    tables_collection.update_one(
        {"table_id": data.table_id},
        {"$set": {"status": "Occupied"}}
    )

    # 7. Mark all selected games as "Being Played"
    games_collection.update_many(
        {"game_id": {"$in": data.game_ids}},
        {"$set": {"status": "Being Played"}}
    )

    return session_doc


def end_session(session_id: str):
   
    session = sessions_collection.find_one({"session_id": session_id})
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    if session["status"] != "Active":
        raise HTTPException(status_code=400, detail="Session is already completed")

    end_time = datetime.utcnow()

    # 1. Update the session document
    sessions_collection.update_one(
        {"session_id": session_id},
        {"$set": {"status": "Completed", "end_time": end_time}}
    )

    # 2. Free up the table
    tables_collection.update_one(
        {"table_id": session["table_id"]},
        {"$set": {"status": "Available"}}
    )

    # 3. Free up all the games that were being played in this session
    games_collection.update_many(
        {"game_id": {"$in": session["game_ids"]}},
        {"$set": {"status": "Available"}}
    )

    updated_session = sessions_collection.find_one({"session_id": session_id})
    return updated_session


def add_game_to_session(session_id: str, game_id: str):

    session = sessions_collection.find_one({"session_id": session_id})
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    if session["status"] != "Active":
        raise HTTPException(status_code=400, detail="Session is not active")

    game = games_collection.find_one({"game_id": game_id})
    if not game:
        raise HTTPException(status_code=404, detail="Game not found")

    if game["status"] != "Available":
        raise HTTPException(status_code=400, detail="Game is not available")

    # Avoid adding the same game twice to one session
    if game_id in session["game_ids"]:
        raise HTTPException(status_code=400, detail="Game already added to this session")

    # 1. Push the new game_id into the session's game_ids array
    sessions_collection.update_one(
        {"session_id": session_id},
        {"$push": {"game_ids": game_id}}
    )

    # 2. Mark the game as "Being Played"
    games_collection.update_one(
        {"game_id": game_id},
        {"$set": {"status": "Being Played"}}
    )

    updated_session = sessions_collection.find_one({"session_id": session_id})
    return updated_session


def get_session_details(session_id: str):
    
    pipeline = [
        # Stage 1: find the session with the matching session_id
        {"$match": {"session_id": session_id}},

        # Stage 2: join with the "tables" collection
        # session.table_id  ==  table.table_id
        {
            "$lookup": {
                "from": "tables",
                "localField": "table_id",
                "foreignField": "table_id",
                "as": "table_info"
            }
        },

        # Stage 3: join with the "games" collection
        # session.game_ids (array) == game.game_id
        {
            "$lookup": {
                "from": "games",
                "localField": "game_ids",
                "foreignField": "game_id",
                "as": "games_info"
            }
        },

        # Stage 4: $lookup always returns an array.
        # Since a session has exactly ONE table, we convert the
        # "table_info" array into a single object using $unwind.
        {
            "$unwind": {
                "path": "$table_info",
                "preserveNullAndEmptyArrays": True
            }
        },
    ]

    results = list(sessions_collection.aggregate(pipeline))

    if not results:
        raise HTTPException(status_code=404, detail="Session not found")

    return results[0]
