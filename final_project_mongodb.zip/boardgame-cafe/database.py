
import os
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "boardgame_cafe")

client = MongoClient(MONGO_URI)

db = client[DB_NAME]

categories_collection = db["categories"]
games_collection = db["games"]
tables_collection = db["tables"]
sessions_collection = db["sessions"]
