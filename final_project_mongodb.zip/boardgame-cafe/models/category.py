
from pydantic import BaseModel, Field
from typing import Optional


class CategoryCreate(BaseModel):
    category_id: str = Field(..., example="CAT001")
    name: str = Field(..., example="Strategy")
    description: Optional[str] = Field(None, example="Strategic board games")


class CategoryUpdate(BaseModel):
    
    name: Optional[str] = None
    description: Optional[str] = None


class CategoryResponse(BaseModel):
    
    category_id: str
    name: str
    description: Optional[str] = None
