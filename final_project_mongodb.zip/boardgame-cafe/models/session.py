"""
A session links together:
- ONE table        (One-to-Many: Table -> Sessions)
- MANY games       (Many-to-Many: Sessions <-> Games)

Status values for a session:
- "Active"    - the group is currently playing
- "Completed" - the group has left and the session has ended
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Literal
from datetime import datetime


SessionStatus = Literal["Active", "Completed"]


class SessionCreate(BaseModel):
    
    session_id: str = Field(..., example="SESSION001")
    group_name: str = Field(..., example="Weekend Gamers")
    table_id: str = Field(..., example="TABLE001")
    game_ids: List[str] = Field(..., example=["GAME001", "GAME002"])
    player_count: int = Field(..., gt=0, example=4)


class SessionStartRequest(BaseModel):
  
    session_id: str = Field(..., example="SESSION001")
    group_name: str = Field(..., example="Weekend Gamers")
    table_id: str = Field(..., example="TABLE001")
    game_ids: List[str] = Field(..., example=["GAME001", "GAME002"])
    player_count: int = Field(..., gt=0, example=4)


class AddGameRequest(BaseModel):
    game_id: str = Field(..., example="GAME003")


class SessionResponse(BaseModel):
    session_id: str
    group_name: str
    table_id: str
    game_ids: List[str]
    player_count: int
    status: SessionStatus
    start_time: datetime
    end_time: Optional[datetime] = None
