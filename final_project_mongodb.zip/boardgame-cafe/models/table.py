"""
Status values for a table:
- "Available" -> table is free and can be assigned to a new group
- "Occupied"  -> table currently has an active session
"""

from pydantic import BaseModel, Field
from typing import Optional, Literal


# A type alias to restrict status to only these two allowed values
TableStatus = Literal["Available", "Occupied"]


class TableCreate(BaseModel):
    
    table_id: str = Field(..., example="TABLE001")
    name: str = Field(..., example="Dragon Table")
    capacity: int = Field(..., gt=0, example=6)
    # Default status when a table is first added
    status: TableStatus = Field(default="Available", example="Available")


class TableUpdate(BaseModel):
    
    name: Optional[str] = None
    capacity: Optional[int] = Field(None, gt=0)
    status: Optional[TableStatus] = None


class TableResponse(BaseModel):

    table_id: str
    name: str
    capacity: int
    status: TableStatus
