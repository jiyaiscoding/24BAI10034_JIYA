

from pydantic import BaseModel, Field
from typing import Optional, Literal

GameStatus = Literal["Available", "Being Played", "Maintenance"]


class GameCreate(BaseModel):
    
    game_id: str = Field(..., example="GAME001")
    name: str = Field(..., example="Catan")
    category_id: str = Field(..., example="CAT001")
    min_players: int = Field(..., gt=0, example=3)
    max_players: int = Field(..., gt=0, example=4)
    # Default status when a game is first added to the library
    status: GameStatus = Field(default="Available", example="Available")


class GameUpdate(BaseModel):
    
    name: Optional[str] = None
    category_id: Optional[str] = None
    min_players: Optional[int] = Field(None, gt=0)
    max_players: Optional[int] = Field(None, gt=0)
    status: Optional[GameStatus] = None


class GameResponse(BaseModel):
    
    game_id: str
    name: str
    category_id: str
    min_players: int
    max_players: int
    status: GameStatus
