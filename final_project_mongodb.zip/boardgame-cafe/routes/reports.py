from fastapi import APIRouter
from database import (
    categories_collection,
    games_collection,
    tables_collection,
    sessions_collection
)

router = APIRouter()

'''1. DASHBOARD REPORT
Gives an overview of the entire cafe.'''

@router.get("/dashboard")
def dashboard_report():

    return {
        "total_categories": categories_collection.count_documents({}),
        "total_games": games_collection.count_documents({}),
        "total_tables": tables_collection.count_documents({}),
        "total_sessions": sessions_collection.count_documents({}),

        "active_sessions": sessions_collection.count_documents(
            {"status": "Active"}
        ),

        "completed_sessions": sessions_collection.count_documents(
            {"status": "Completed"}
        ),

        "available_games": games_collection.count_documents(
            {"status": "Available"}
        ),

        "games_in_use": games_collection.count_documents(
            {"status": "Being Played"}
        ),

        "available_tables": tables_collection.count_documents(
            {"status": "Available"}
        ),

        "occupied_tables": tables_collection.count_documents(
            {"status": "Occupied"}
        )
    }


'''# 2. SESSION HISTORY SUMMARY
# Gives a summary of all sessions.'''

@router.get("/session-history")
def session_history():

    total_sessions = sessions_collection.count_documents({})

    completed_sessions = sessions_collection.count_documents(
        {"status": "Completed"}
    )

    active_sessions = sessions_collection.count_documents(
        {"status": "Active"}
    )

    return {
        "total_sessions": total_sessions,
        "completed_sessions": completed_sessions,
        "active_sessions": active_sessions
    }


''' 3. MOST PLAYED GAMES
# Counts how many times each game appears in all sessions.'''

@router.get("/most-played-games")
def most_played_games():

    pipeline = [

     
        {
            "$unwind": "$game_ids"
        },


        {
            "$group": {
                "_id": "$game_ids",
                "times_played": {
                    "$sum": 1
                }
            }
        },

    
        {
            "$sort": {
                "times_played": -1
            }
        }
    ]

    results = list(
        sessions_collection.aggregate(pipeline)
    )

    response = []

    for item in results:

        game = games_collection.find_one(
            {"game_id": item["_id"]}
        )

        response.append({
            "game_id": item["_id"],
            "game_name": game["name"] if game else "Unknown",
            "times_played": item["times_played"]
        })

    return response



'''# 4. MOST USED TABLES
# Counts how many sessions each table hosted.'''

@router.get("/most-used-tables")
def most_used_tables():

    pipeline = [

        {
            "$group": {
                "_id": "$table_id",
                "sessions_hosted": {
                    "$sum": 1
                }
            }
        },

        {
            "$sort": {
                "sessions_hosted": -1
            }
        }
    ]

    results = list(
        sessions_collection.aggregate(pipeline)
    )

    response = []

    for item in results:

        table = tables_collection.find_one(
            {"table_id": item["_id"]}
        )

        response.append({
            "table_id": item["_id"],
            "table_name": table["name"] if table else "Unknown",
            "sessions_hosted": item["sessions_hosted"]
        })

    return response