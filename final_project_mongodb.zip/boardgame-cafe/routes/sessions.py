"""
This file has two parts:

1. BASIC CRUD
   - GET /sessions/        -> get all sessions
   - GET /sessions/{id}     -> get one session
   - DELETE /sessions/{id}  -> delete a session
   (Note: "Create" for sessions is done through /sessions/start,
    which contains important business logic - see below.)

2. BUSINESS LOGIC ENDPOINTS (handled by services/session_service.py)
   - POST /sessions/start
   - POST /sessions/end/{session_id}
   - POST /sessions/{session_id}/add-game
   - GET  /sessions/details/{session_id}
"""

import json
from bson import json_util
from fastapi import APIRouter, HTTPException
from typing import List

from database import sessions_collection
from models.session import SessionResponse, SessionStartRequest, AddGameRequest
from services import session_service

router = APIRouter(prefix="/sessions", tags=["Sessions"])


def mongo_to_dict(document):
    return json.loads(json_util.dumps(document))



# BASIC CRUD ENDPOINTS


@router.get("/", response_model=List[SessionResponse])
def get_all_sessions():
    """Return a list of all sessions (active and completed)."""
    sessions = []
    for session in sessions_collection.find({}):
        sessions.append(session)
    return sessions


@router.get("/{session_id}", response_model=SessionResponse)
def get_session(session_id: str):
    """Return a single session by its session_id."""
    session = sessions_collection.find_one({"session_id": session_id})
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session


@router.delete("/{session_id}")
def delete_session(session_id: str):
    """Delete a session by its session_id (for cleanup/testing purposes)."""
    result = sessions_collection.delete_one({"session_id": session_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Session not found")
    return {"message": f"Session '{session_id}' deleted successfully"}


# BUSINESS LOGIC ENDPOINTS

@router.post("/start", response_model=SessionResponse)
def start_session(data: SessionStartRequest):

    session = session_service.start_session(data)
    return session


@router.post("/end/{session_id}", response_model=SessionResponse)
def end_session(session_id: str):
    session = session_service.end_session(session_id)
    return session


@router.post("/{session_id}/add-game", response_model=SessionResponse)
def add_game_to_session(session_id: str, data: AddGameRequest):

    session = session_service.add_game_to_session(session_id, data.game_id)
    return session


@router.get("/details/{session_id}")
def get_session_details(session_id: str):
   
    session = session_service.get_session_details(session_id)
    return mongo_to_dict(session)
