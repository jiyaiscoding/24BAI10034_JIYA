"""
CRUD endpoints for the "categories" collection.

A category represents a type of board game (e.g., Strategy, Party, Card).
Relationship: One Category -> Many Games (category_id is stored in each game)
"""

from fastapi import APIRouter, HTTPException
from typing import List

from database import categories_collection
from models.category import CategoryCreate, CategoryUpdate, CategoryResponse

router = APIRouter(prefix="/categories", tags=["Categories"])


@router.post("/", response_model=CategoryResponse)
def create_category(category: CategoryCreate):
    # Check for duplicate category_id
    existing = categories_collection.find_one({"category_id": category.category_id})
    if existing:
        raise HTTPException(status_code=400, detail="category_id already exists")

    categories_collection.insert_one(category.dict())

    return category


@router.get("/", response_model=List[CategoryResponse])
def get_all_categories():
    categories = []
    for cat in categories_collection.find({}):
        categories.append(cat)
    return categories


@router.get("/{category_id}", response_model=CategoryResponse)
def get_category(category_id: str):
    category = categories_collection.find_one({"category_id": category_id})
    if not category:
        raise HTTPException(status_code=404, detail="Category not found")
    return category


@router.put("/{category_id}", response_model=CategoryResponse)
def update_category(category_id: str, category: CategoryUpdate):
    """
    Update an existing category.
    """
    existing = categories_collection.find_one({"category_id": category_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Category not found")

    # Get only the fields the user actually sent
    update_data = category.dict(exclude_unset=True)

    if update_data:
        categories_collection.update_one(
            {"category_id": category_id},
            {"$set": update_data}
        )

    updated = categories_collection.find_one({"category_id": category_id})
    return updated


@router.delete("/{category_id}")
def delete_category(category_id: str):
    """Delete a category by its category_id."""
    result = categories_collection.delete_one({"category_id": category_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Category not found")
    return {"message": f"Category '{category_id}' deleted successfully"}
