"""
CRUD endpoints for the "games" collection.

Relationship: Many Games -> One Category (each game stores a category_id)
"""

from fastapi import APIRouter, HTTPException
from typing import List

from database import games_collection, categories_collection
from models.game import GameCreate, GameUpdate, GameResponse

router = APIRouter(prefix="/games", tags=["Games"])


@router.post("/", response_model=GameResponse)
def create_game(game: GameCreate):
    
    existing = games_collection.find_one({"game_id": game.game_id})
    if existing:
        raise HTTPException(status_code=400, detail="game_id already exists")

    category = categories_collection.find_one({"category_id": game.category_id})
    if not category:
        raise HTTPException(status_code=404, detail="category_id does not exist")

    games_collection.insert_one(game.dict())
    return game


@router.get("/", response_model=List[GameResponse])
def get_all_games():

    games = []
    for game in games_collection.find({}):
        games.append(game)
    return games


@router.get("/{game_id}", response_model=GameResponse)
def get_game(game_id: str):

    game = games_collection.find_one({"game_id": game_id})
    if not game:
        raise HTTPException(status_code=404, detail="Game not found")
    return game


@router.put("/{game_id}", response_model=GameResponse)
def update_game(game_id: str, game: GameUpdate):
    existing = games_collection.find_one({"game_id": game_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Game not found")

    update_data = game.dict(exclude_unset=True)

    # If category_id is being updated, make sure the new category exists
    if "category_id" in update_data:
        category = categories_collection.find_one(
            {"category_id": update_data["category_id"]}
        )
        if not category:
            raise HTTPException(status_code=404, detail="category_id does not exist")

    if update_data:
        games_collection.update_one(
            {"game_id": game_id},
            {"$set": update_data}
        )

    updated = games_collection.find_one({"game_id": game_id})
    return updated


@router.delete("/{game_id}")
def delete_game(game_id: str):
    result = games_collection.delete_one({"game_id": game_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Game not found")
    return {"message": f"Game '{game_id}' deleted successfully"}
