"""
routes/tables.py

CRUD endpoints for the "tables" collection.

Relationship: One Table -> Many Sessions (over time)
"""

from fastapi import APIRouter, HTTPException
from typing import List

from database import tables_collection
from models.table import TableCreate, TableUpdate, TableResponse

router = APIRouter(prefix="/tables", tags=["Tables"])


@router.post("/", response_model=TableResponse)
def create_table(table: TableCreate):
    """Create a new table. table_id must be unique."""
    existing = tables_collection.find_one({"table_id": table.table_id})
    if existing:
        raise HTTPException(status_code=400, detail="table_id already exists")

    tables_collection.insert_one(table.dict())
    return table


@router.get("/", response_model=List[TableResponse])
def get_all_tables():
    """Return a list of all tables."""
    tables = []
    for table in tables_collection.find({}):
        tables.append(table)
    return tables


@router.get("/{table_id}", response_model=TableResponse)
def get_table(table_id: str):
    """Return a single table by its table_id."""
    table = tables_collection.find_one({"table_id": table_id})
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    return table


@router.put("/{table_id}", response_model=TableResponse)
def update_table(table_id: str, table: TableUpdate):
    """Update an existing table. Only provided fields are changed."""
    existing = tables_collection.find_one({"table_id": table_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Table not found")

    update_data = table.dict(exclude_unset=True)

    if update_data:
        tables_collection.update_one(
            {"table_id": table_id},
            {"$set": update_data}
        )

    updated = tables_collection.find_one({"table_id": table_id})
    return updated


@router.delete("/{table_id}")
def delete_table(table_id: str):
    """Delete a table by its table_id."""
    result = tables_collection.delete_one({"table_id": table_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Table not found")
    return {"message": f"Table '{table_id}' deleted successfully"}
